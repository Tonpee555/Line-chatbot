import httpx
import os

# ============================
# Claude API Config
# ============================
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# ============================
# System Prompt — แก้ตรงนี้!
# ============================
SYSTEM_PROMPT = """คุณคือผู้ช่วยอัจฉริยะของ [ชื่อธุรกิจของคุณ]
ตอบภาษาไทยเท่านั้น ด้วยน้ำเสียงสุภาพ กระชับ และเป็นมิตร
ห้ามตอบเรื่องที่ไม่เกี่ยวกับธุรกิจของเรา
หากไม่ทราบคำตอบ ให้บอกว่า 'ขออภัยค่ะ ไม่ทราบข้อมูลในส่วนนี้ กรุณาติดต่อเจ้าหน้าที่ได้เลยค่ะ'
"""

# ============================
# เก็บประวัติการสนทนาแต่ละ user
# (สำหรับ production ควรใช้ Redis หรือ DB แทน)
# ============================
conversation_history: dict = {}
MAX_HISTORY = 10  # จำกัดประวัติไม่เกิน 10 รอบ


async def fetch_answer(user_message: str, user_id: str = "default") -> str:
    """
    ส่งข้อความของผู้ใช้ไปให้ Claude แล้วรับคำตอบกลับ
    รองรับการจำบทสนทนา (multi-turn conversation)
    """

    # เพิ่มข้อความใหม่ลงประวัติ
    if user_id not in conversation_history:
        conversation_history[user_id] = []

    conversation_history[user_id].append({
        "role": "user",
        "content": user_message
    })

    # ตัดประวัติถ้ายาวเกินไป
    if len(conversation_history[user_id]) > MAX_HISTORY * 2:
        conversation_history[user_id] = conversation_history[user_id][-MAX_HISTORY * 2:]

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": CLAUDE_MODEL,
                    "max_tokens": 500,
                    "system": SYSTEM_PROMPT,
                    "messages": conversation_history[user_id],
                }
            )

            if response.status_code == 200:
                data = response.json()
                assistant_reply = data["content"][0]["text"]

                # บันทึกคำตอบของ Claude ลงประวัติ
                conversation_history[user_id].append({
                    "role": "assistant",
                    "content": assistant_reply
                })

                return assistant_reply

            else:
                print(f"[ERROR] Claude API: {response.status_code} - {response.text}")
                return "ขออภัยค่ะ ระบบขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้งนะคะ"

    except Exception as e:
        print(f"[ERROR] fetch_answer: {e}")
        return "เกิดข้อผิดพลาด กรุณาติดต่อเจ้าหน้าที่ค่ะ"


def clear_history(user_id: str):
    """ล้างประวัติสนทนาของ user (เช่น เมื่อผู้ใช้พิมพ์ 'เริ่มใหม่')"""
    if user_id in conversation_history:
        del conversation_history[user_id]
